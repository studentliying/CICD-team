INSERT into users VALUES(1,'admin','123456');
INSERT into roles values(1,'超级管理员'),(2,'普通用户');
INSERT into user_roles VALUES(1,1,1),(2,1,2);